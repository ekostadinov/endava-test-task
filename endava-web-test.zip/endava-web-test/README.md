
Setup:
 
 1. Python version: 3.6.x
 
     1.1 For windows you can get it from here:
     
     ``https://www.python.org/downloads/``
     
 2. If you are using Windows 10, please update your `long path`, following this tutorial:
     
     ``https://blogs.msdn.microsoft.com/jeremykuhne/2016/07/30/net-4-6-2-and-long-paths-on-windows-10/``
     
 3. After python 3.6.x is installed successfully, run:

```
    cd your/local/directory
    pip3 install -r requirements.txt
    python -m unittest amazon_tests.AmazonTests           
```

**NOTE:**
- you need to download, place in `/drivers` and set proper permissions of the chromedriver as per your OS
- the current Amazon flow is changed a bit, but I have kept the test as much as possible:
  e.g not all toys have quantity https://www.amazon.com/LEGO-Starship-Building-Awesome-Pieces/dp/B08YP8HGLV/ref=sr_1_25?dchild=1&keywords=Star+Wars&qid=1633002725&refinements=p_36%3A5000-50000%2Cp_89%3ALEGO&rnid=2528832011&s=toys-and-games&sr=1-25 and could be added to cart
- this repo contains mainly the raw, simple coding needed to accomplish the task at hand, any furter design, infrastructure and pipelines should be aligned with the actual needs
