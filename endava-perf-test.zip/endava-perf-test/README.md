
Setup:
 
 1. Install and setup proper Java version (e.g v17)
 
     
 2. Install JMeter, for Mac OS use:
     
     `brew install jmeter`
     
 3. After JMeter is installed successfully, run:

```
    cd your/local/directory
    open /usr/local/bin/jmeter
```

 4. Load `Endava_task.jmx` and run the tests

**NOTE:**
- I have used the public webpagetest.org
